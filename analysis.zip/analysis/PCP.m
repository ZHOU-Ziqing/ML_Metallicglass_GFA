clc;

clear;

features = xlsread('Final_dataset_all.xlsx','E2:L1226');

parallelcoords(features);