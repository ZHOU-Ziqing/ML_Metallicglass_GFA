clc;

clear;

interval=10;
n=100/interval;


a=0;
for i=1:n
    for j=1:n
        for k=1:n
            for l=1:n
                for m=1:n
                    for p=1:n
                        if i+j+k+l+m+p==100/interval
                            
                            a=a+1;
                            A(a)=i*interval;
                            B(a)=j*interval;
                            C(a)=k*interval;
                            D(a)=l*interval;
                            E(a)=m*interval;
                            F(a)=p*interval;
                            
                        end
                    end
                end
            end
        end
    end
end

frac=[A;B;C;D;E;F];

N=length(frac);

b=0;

% for i=1:N
%     if max(frac(:,i))==frac(1,i)
%         b=b+1;
%         fraction(:,b)=frac(:,i);
%     end
% end

