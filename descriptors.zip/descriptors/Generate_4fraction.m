clc;

clear;

interval=1;
n=100/interval;

a=0;
for i=1:n
    for j=1:n
        for k=1:n
            for l=1:n
                if i+j+k+l==100/interval
                    a=a+1;
                    A(a)=i*interval;
                    B(a)=j*interval;
                    C(a)=k*interval;
                    D(a)=l*interval;
                end
            end
        end
    end
end


frac=[A;B;C;D];

N=length(frac);

b=0;
for i=1:N
    if max(frac(:,i))==frac(1,i)
        b=b+1;
        fraction(:,b)=frac(:,i);
    end
end
id=frac(1,:)<40 | frac(1,:)>55 | frac(2,:)<15 | frac(2,:)>35|frac(3,:)<10|frac(3,:)>20|frac(4,:)<5|frac(4,:)>20;
frac(:,id)=[];
fraction=frac;
