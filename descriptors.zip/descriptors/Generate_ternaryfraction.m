clc;

clear;

interval=2;
n=100/interval;

a=0;
for i=1:n
    for j=1:n
        for k=1:n
            if i+j+k==100/interval
                a=a+1;
                X(a)=i*interval;
                Y(a)=j*interval;
                Z(a)=k*interval;
            end
        end
    end
end
fraction=[X;Y;Z];

%N=length(frac);

% b=0;
% for i=1:N
%     if max(frac(:,i))==frac(1,i)
%         b=b+1;
%         fraction(:,b)=frac(:,i);
%     end
% end

% id=frac(1,:)<82 | frac(1,:)>92 | frac(2,:)<6 | frac(2,:)>16|frac(3,:)<2|frac(3,:)>12;
% frac(:,id)=[];
% fraction=frac;