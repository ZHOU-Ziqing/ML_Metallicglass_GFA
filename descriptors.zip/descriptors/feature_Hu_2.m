function[features]=feature_Hu_2(comp,frac)

E = xlsread('interactionenergy.xlsx','B2:CF84');

m=length(comp);

sumall=0;
for i=1:m
    sumall=sumall+frac(i);
end
c=frac/sumall; 

coE=zeros(1,m);
for i=1:m
    coE(i)=E(comp(i),comp(i));
end

McoE=0;                              
for  i=1:m
    McoE=McoE+c(i)*coE(i);      %the average atomic radius
end
DcoE=0;
for  i=1:m
    DcoE=DcoE+c(i)*(coE(i)-McoE)^2;
end
DcoE=sqrt(DcoE);
MinE=0;
for i=1:m
    for j=1:m
        if i~=j
            MinE=MinE+c(i)*c(j)*E(comp(i),comp(j));
        end
    end
end
MinE=MinE/McoE;

features(1)=DcoE;
features(2)=MinE;