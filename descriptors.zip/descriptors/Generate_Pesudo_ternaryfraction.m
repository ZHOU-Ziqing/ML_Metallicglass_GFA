clc;

clear;

interval=4;
n=100/interval;

a=0;
for i=1:n
    for j=1:n
        for k=1:n
            if i+j+k==100/interval
                a=a+1;
                X(a)=i*interval;
                Y(a)=j*interval;
                Z(a)=k*interval;
            end
        end
    end
end
Z1=Z/2;
Z2=Z/2;
fraction=[X;Y;Z1;Z2];