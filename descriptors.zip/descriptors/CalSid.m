function[S_id] = CalSid(comp,ele_frac)

n=length(comp);

sum=0;
for i=1:n
    sum=sum+ele_frac(i);
end
c=ele_frac/sum; %normalized fraction

    %ideal mixing entropy
S_id=0;
for i=1:n
    S_id=S_id+c(i)*log(c(i));
end
S_id=-S_id;

