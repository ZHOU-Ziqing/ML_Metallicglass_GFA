clc;

load('MLmodel_4Fin.mat');
load('Fin_classificationmodels.mat');

%xx=xlsread('Ternary_small_ZrCuAl.xlsx','F2:M277');
%xx=xlsread('RQGPR_MG.xlsx','E2:L24');
%xx=xlsread('Opt_HEBMG.xlsx','E2:L66');
%xx=xlsread('LaAlNi.xlsx','G2:N11629');
xx=xlsread('Zr56Co18Cu12Al7Hf6Ti1_0.2.xlsx','G2:N116290');
%xx=xlsread('Al_based_5_noTi.xlsx','G2:N200000');
%load('MLmodels_4.mat');


y_RQGPR=RQGPR.predictFcn(xx);

%y_ExpGPR=ExpGPR.predictFcn(xx);

%y_SqExpGPR=SqExpGPR.predictFcn(xx);

%y_GSVM=GSVM.predictFcn(xx);

%y_GSVM=GSVM.predictFcn(xx);

%y_FKNN=FKNN.predictFcn(xx);

y_RF=RF.predictFcn(xx);