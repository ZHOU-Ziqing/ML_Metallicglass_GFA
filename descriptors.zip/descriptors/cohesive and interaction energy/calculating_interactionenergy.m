clc;

E=xlsread('Cohesive_energy','D2:D84');
I=xlsread('Ionization_energy','D2:D84');
r=xlsread('properties','C2:C84');
London=zeros(83,83);

for i=1:83
    for j=1:83
        if r(i)&r(j)
        London(i,j)=2*sqrt(E(i)*E(j))/(E(i)+E(j))*((2*sqrt(r(i)*r(j)))/(r(i)+r(j)))^6;
        eps(i,j)=London(i,j)*sqrt(E(i)*E(j));
        end
    end
end

