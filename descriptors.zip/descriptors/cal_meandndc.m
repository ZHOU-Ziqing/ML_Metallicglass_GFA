function[features]=cal_meandndc(b,c,d,p)

load('Meanvalue.mat');

n=length(b);

Meandc=Mean_dc(n);%Arithmetic mean
Meandn=Mean_dn(n);

Meansquaredc=Meansquare_dc(n);%Weighted mean
Meansquaredn=Meansquare_dn(n);

SDdc=SD_dc(n);%standard deviation
SDdn=SD_dn(n);

B=sym(zeros(n,1));%four constrants
C=sym(zeros(n,1));
D=sym(zeros(n,n));
P=sym(zeros(n,n));

for i=1:n
        
    C(i)=sym(['c',num2str(i)]);
    B(i)=sym(['b',num2str(i)]);
    D(i)=sym(['d',num2str(i)]);
    for j=1:n
        
        P(i,j)=sym(['p',num2str(i),num2str(j)]);
        
        if i==j
            D(i,i)=sym(['d',num2str(i)]);
        end
        
    end
end

Value_Meandc=double(subs(subs(subs(subs(Meandc,B,b),C,c),D,d),P,p));
Value_Meandn=double(subs(subs(subs(subs(Meandn,B,b),C,c),D,d),P,p));

Value_Meansquaredc=double(subs(subs(subs(subs(Meansquaredc,B,b),C,c),D,d),P,p));
Value_Meansquaredn=double(subs(subs(subs(subs(Meansquaredn,B,b),C,c),D,d),P,p));

Value_SDdc=double(subs(subs(subs(subs(SDdc,B,b),C,c),D,d),P,p));
Value_SDdn=double(subs(subs(subs(subs(SDdn,B,b),C,c),D,d),P,p));

features=zeros(1,6);%6 features
features(1)=Value_Meandc;
features(2)=Value_Meandn;
features(3)=Value_Meansquaredc;
features(4)=Value_Meansquaredn;
features(5)=Value_SDdc;
features(6)=Value_SDdn;


