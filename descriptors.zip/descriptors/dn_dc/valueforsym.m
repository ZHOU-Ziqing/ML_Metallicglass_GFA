clc;

