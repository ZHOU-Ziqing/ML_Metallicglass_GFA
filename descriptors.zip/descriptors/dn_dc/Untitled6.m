clc;
clear;
syms x y;
a=3;
x=a;
b=str2double(x);