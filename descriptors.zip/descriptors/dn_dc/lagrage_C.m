clc;
clear;

syms l1 l2 l3;
n=2;
for i=1:n
    for j=1:n
       C(i)=sym(['c',num2str(i)]);
       P(i,j)=sym(['p',num2str(i),num2str(j)]);
       B(i)=sym(['b',num2str(i)]);
       dC(i)=sym(['dc',num2str(i)]);
       if i==j
           M(i,i)=sym(['m',num2str(i)]);
       else           
           M(i,j)='0';
       end    
    end
end
for i=1:2
    L(i)=sym(['l',num2str(i)]);
end
B=transpose(B);
dC=transpose(dC);
L=transpose(L);
C=transpose(C);
E=B+P*dC;
f=transpose(E)*M*E;
vars=dC;
answer=cat(1,vars,L);

answer=solve(transpose(C)*E, sum(dC), jacobian(f,vars)-l1*jacobian(transpose(C)*E,vars)-l2*jacobian(sum(dC),vars),vars);


