clc;
clear;

syms l1 l2 l3;

Mean_dn=sym(zeros(9,1));
Mean_dc=sym(zeros(9,1));
Meansquare_dn=sym(zeros(9,1));
Meansquare_dc=sym(zeros(9,1));
SD_dn=sym(zeros(9,1));
SD_dc=sym(zeros(9,1));
for n=2:9
    
    C=sym(zeros(n,1));
    P=sym(zeros(n,n));
    B=sym(zeros(n,1));
    dN=sym(zeros(n,1));
    dC=sym(zeros(n,1));
    D=sym(zeros(n,n));
    M=sym(zeros(n,n));
    
    for i=1:n
        
        C(i)=sym(['c',num2str(i)]);
        B(i)=sym(['b',num2str(i)]);
        dN(i)=sym(['dn',num2str(i)]);
        dC(i)=sym(['dc',num2str(i)]);
        
        for j=1:n
        
        P(i,j)=sym(['p',num2str(i),num2str(j)]);        
        if i==j
            D(i,i)=sym(['d',num2str(i)]);
            M(i,i)=sym(['m',num2str(i)]);
        end    
        
        end
    end

    L=sym(zeros(3,1));
    
    for i=1:3
        L(i)=sym(['l',num2str(i)]);
    end


    E=B+D*dN+P*dC;%express of strain

    f=transpose(E)*M*E;%EMS strain or strain elastic energy

    vars=cat(1,dN,dC);
    varsall=cat(1,vars,L);

    answer=solve(transpose(C)*E, transpose(C)*dC, transpose(C)*dN, jacobian(f,vars)+l1*jacobian(transpose(C)*E,vars)+l2*jacobian(transpose(C)*dC,vars)+l3*jacobian(transpose(C)*dN,vars),varsall);

    struct=fieldnames(answer);

    for i=1:n
        solve_dn(i)=eval(['answer.',struct{i}]);
        solve_dc(i)=eval(['answer.',struct{i+n}]);
    end

    Mean_dn(n)=mean(solve_dn);
    Mean_dc(n)=mean(solve_dc);
    
    Meansquare_dn(n)=sqrt((solve_dn.^2)*C);
    Meansquare_dc(n)=sqrt((solve_dc.^2)*C);
    
    SD_dn(n)=sqrt(((sqrt(solve_dn.^2)-Meansquare_dn(n))*C)^2);
    SD_dc(n)=sqrt(((sqrt(solve_dc.^2)-Meansquare_dc(n))*C)^2);
    
end

save('Meanvalue.mat','Mean_dc','Mean_dn','Meansquare_dc','Meansquare_dn','SD_dn','SD_dc');
