function[radio] = ScorrSid(comp,c,T,data,enthalpy)

ntotal=length(comp);

    %atomic radius
for i=1:ntotal
    r(i)=data(comp(i));
end
    %atomic lattice constant of FCC structure
a=r*2^1.5;

    %lattice constant
an=3.585;

    %coordination number of FCC
CN=12;

    %calculate w(i,j), A(i,j), the second term of equation 6
cjwA=0;
for  i=1:ntotal
    cjw(i)=0;
    cjA(i)=0;
    for j=1:ntotal
        x(i,j)=r(i)/r(j);
        w(i,j)=2*pi*(1-(r(i)*(r(i)+2*r(j)))^0.5/(r(i)+r(j)));
        A(i,j)=2*pi*x(i,j)/(x(i,j)+1)^2/(x(i,j)*(x(i,j)+2))^0.5;
        cjw(i)=cjw(i)+c(j)*w(i,j);
        cjA(i)=cjA(i)+c(j)*A(i,j);
    end
    cjwA=cjwA+a(i)*c(i)*cjw(i)/cjA(i);
end  

aici=0;
temp1=0;
for i=1:ntotal
    aici=aici+a(i)*c(i);
    temp2=0;
    for j=1:ntotal
        temp2=temp2+c(j)*A(i,j);
    end
    temp1=temp1+a(i)*c(i)/temp2;
end
tem=(aici+cjwA-an)/temp1;%temp is 4*pi*n/N

    %calculate residual strain e(i)
for i=1:ntotal
    e(i)=(cjw(i)-tem)/cjA(i);
end

    %calculate ideal residual strain e(i)
n=0;
for i=1:ntotal
    for j=1:ntotal
        n=n+c(i)*c(j)*CN*(1-(x(i,j)*(x(i,j)+2))^0.5/(x(i,j)+1));
    end
end
n=n/2;
for i=1:ntotal
    ideal_e(i)=(cjw(i)-4*pi*n/CN)/cjA(i);
end

    %calculate root mean residual strain e(i)
root_e=0;
root_ie=0;
for i=1:ntotal
    root_e=root_e+c(i)*e(i)^2;
    root_ie=root_ie+c(i)*ideal_e(i)^2;
end
root_e=root_e^0.5;
root_ie=root_ie^0.5;

    %Lattice constant
a_d=0;
r_ave=0;
for i=1:ntotal
    r_ave=r_ave+c(i)*r(i)*(1+ideal_e(i));
    a_d=a_d+c(i)*r(i)*2^1.5*(1+ideal_e(i));
end

    %volume per atom
V=4/3*pi*(r_ave)^3*1e-30;

    %average bulk modulus B
B_ave=0;
B=zeros(ntotal,1);
for i=1:ntotal
    B(i)=data(comp(i),6);
end
for i=1:ntotal
    
    B_ave=B_ave+c(i)*B(i);
end
B_ave=B_ave*1e9;


    %Boltzmann constant
k=1.380645*1e-23;

    %elastic energy fluctuation delta elastic energy/kT
x_e=3*2^0.5*root_ie*(B_ave*V/(k*T))^0.5;




    %mixing enthalpy
H_ave=0;
t=0;
for i=1:ntotal
    for j=1:ntotal
        if j~=i
            H_ave=H_ave+enthalpy(comp(i),comp(j));
        end
    end
end
H_ave=H_ave/(ntotal^2-ntotal);

temp=0;
for i=1:ntotal
    for j=1:ntotal  
       if j~=i
            temp=temp+c(i)*c(j)*(enthalpy(comp(i),comp(j))-H_ave)^2; 
           end
    end
end

    %avogadro's constant
NA=6.0221*1e23;

    %chemical bond fluctuation 
x_cb=2*(temp^0.5*1e3/NA/k/T)^0.5;


    %ideal mixing entropy
S_id=0;
for i=1:ntotal
    S_id=S_id+c(i)*log(c(i));
end
S_id=-S_id;
Scorr=S_id+SE(x_e+x_cb);
ratio=Scorr/S_id;




