function[Scorr] = CalScorr(comp,ele_frac)

data1_ld = xlsread('properties.xlsx','c2:H84');
enthalpy = xlsread('mixingenthalpy.xlsx','c3:CG85');  %read the mixing enthalpy in the database

n=length(comp);

sum=0;
for i=1:n
    sum=sum+ele_frac(i);
end
c=ele_frac/sum; %normalized fraction

radio = data1_ld(:,1);
meltingTem = data1_ld(:,2);

bulkmodulus = data1_ld(:,6);

r = zeros(n,1);
Tm = zeros(n,1);
K = zeros(n,1);

for i=1:n
    r(i) = radio(comp(i));
    Tm(i) = meltingTem(comp(i));
    K(i) = bulkmodulus(comp(i));
end

r_ave=0;
Tm_ave=0;
K_ave=0;

for  i=1:n
    r_ave=r_ave+r(i)*c(i);      %the average atomic radius
    Tm_ave=Tm_ave+Tm(i)*c(i);   %the average melting point
    K_ave=K_ave+K(i)*c(i);      %the average bulk modulus
end

    %volume per atom
V=4/3*pi*(r_ave)^3*1e-30;

    %Boltzmann constant
k_B=1.380645*1e-23;

RMS=feature_ye(comp,c);
    %elastic energy fluctuation delta elastic energy/kT
x_e=3*2^0.5*RMS(1)*(K_ave*V/(k_B*Tm_ave))^0.5;


%mixing enthalpy
H_ave=0;
for i=1:n
    for j=1:n
        if j~=i
            H_ave=H_ave+c(i)*c(j)*enthalpy(comp(i),comp(j));
        end
    end
end
H_ave=4*H_ave;

temp=0;
for i=1:n
    for j=1:n 
       if j~=i
            temp=temp+c(i)*c(j)*(enthalpy(comp(i),comp(j))-H_ave)^2; 
           end
    end
end

%avogadro's constant
NA=6.0221*1e23;

    %chemical bond fluctuation 
x_c=2*(temp^0.5*1e3/NA/k_B/Tm_ave)^0.5;


    %ideal mixing entropy
S_id=0;
for i=1:n
    S_id=S_id+c(i)*log(c(i));
end
S_id=-S_id;
Scorr=S_id+SE(x_e+x_c);


