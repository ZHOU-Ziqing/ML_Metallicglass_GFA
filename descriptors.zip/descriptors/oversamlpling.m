clc;

features = xlsread('Final_dataset_all_1.xlsx','E4941:L6933');
labels = xlsread('Final_dataset_all_1.xlsx','X4941:X6933');

[X,C,Xn,Cn] = smote(features,1.5,5);