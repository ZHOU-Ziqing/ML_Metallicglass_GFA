function[RMS]=feature_ye(comp, ele_frac)

data1_ld = xlsread('properties.xlsx','c2:H84');

radius = data1_ld(:,1);  %the atomic size

bulk = data1_ld(:,6);%bulk modulus

n = length(comp);%number of elements
sum=0;
for i=1:n
    sum=sum+ele_frac(i);
end
c=ele_frac/sum; %normalized fraction
r=zeros(n,1);%simplified radio
K=zeros(n,1);%simplified bulk modulus
for i=1:n
    r(i)=radius(comp(i));
    K(i)=bulk(comp(i));
end

w=zeros(n,n);
for i=1:n
    for j=1:n
        w(i,j)=2*pi*(1-sqrt(r(i)*(r(i)+2*r(j)))/(r(i)+r(j)));
    end
end

x=zeros(n,n);
for i=1:n
    for j=1:n
        x(i,j)=r(i)/r(j);
    end
end

A=zeros(n,n);
for i=1:n
    for j=1:n
        A(i,j)=2*pi*x(i,j)/((x(i,j)+1)^2*sqrt(x(i,j)*(x(i,j)+2)));
    end
end

eta=0;
for i=1:n
    for j=1:n
        eta=eta+0.5*c(j)*c(i)*(1-sqrt(x(i,j)*(x(i,j)+2))/(x(i,j)+1));
    end
end

AC=zeros(n,1);
WC=zeros(n,1);
strain=zeros(n,1);
for i=1:n
	for j=1:n
    AC(i)=AC(i)+A(i,j)*c(j);
    WC(i)=WC(i)+w(i,j)*c(j);
    end
end

for i=1:n
    strain(i)=WC(i)/AC(i)-4*pi*eta/AC(i);
end


C=zeros(n,n);
M=zeros(n,n);
for i=1:n
    for j=1:n
        if i==j
            C(i,j)=c(i);
            M(i,j)=(r(i)/mean(r))^3*(K(i)/mean(K))*c(i);
        end
    end
end

RMS=sqrt(strain'*C*strain);%R.M.S strain
ue=strain'*M*strain;%dimensionless stored elastic energy

