clc;

clear;

y=xlsread('D_new2_1','W2:W724');

f=xlsread('D_new2_1','X2:X724');

num=length(y);

Mean_y=sum(y)/num;

TOT=sum((y-Mean_y).^2);

RES=sum((y-f).^2);

Rsq=1-RES/TOT;

